function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(255, 255, 0);
  circle(200, 200, 100);
}